
## Overview

The filesystem is divided into four locations depending on the purpose of the file: webFiles, cdnFiles, privateFiles and tempFiles. In addition, the site can be set to store files on Amazon AWS and keep a mirror copy locally or store files locally, depending on the site's needs

## Local vs Remote Files

When the system is configured 

## webFiles


## cdnFiles


## privateFiles


## tempFiles

## Developers

## References

[Google Developer details for Favicon](https://developers.google.com/search/docs/appearance/favicon-in-search)

