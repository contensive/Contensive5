Html Import it a tool that lets you upload Page Templates and Add-on Layouts with their assets (images, styles, javascript) and does transformations that assist a designer.

For more information, run the Html-Import tool under the Tools icon in the admin site, and see the instructions on it's main page.