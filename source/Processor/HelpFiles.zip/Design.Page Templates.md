Page Templates are html documents used when displaying website pages.

### Eding Page Templates

Page Templates are stored in the Page Templates site content. To edit Page Templates, go to the admin site and click the Design icon, and click Page Templates from the flyout.

### Importing Page Templates using Html-Import

The html-Import tool (under the Tools icon) lets you upload a Page Template with it's assets (images, styles, js) and perform transformations that modify the template to help a designer add and remote elements.

See Design > html-import for more details

### Using an Add-on to Customize a Page Template

Use the Page Template's Add-on field to implement Mustache customizations to the template.

See Design > Mustache Templating for more details

