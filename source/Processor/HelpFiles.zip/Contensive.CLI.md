
The Contensive command line tool (cc.exe) performs maintenance tasks, as well as code execution for any of the applications configured in the (application server group)[/help/contensive/Setup and Configuration].

For command details, execute cc.exe (without arguments)

## References

<a href="/help/Contensive/Configure Server">cc --configure</a>