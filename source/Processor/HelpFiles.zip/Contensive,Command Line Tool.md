
## Overview

The Contensive command line tool (cc.exe) performs maintenance tasks, as well as code execution for any of the applications configured in the (application server group)[/help/contensive/Setup and Configuration].

## Developers

## References

