
> Create a copy of an application. You might do this creating a dev site from a staging site

## Create a New Application

> cc.exe --newapp
>
> Use the newapp command to create a new application on the server with the same name and settings as the source application.

### Copy resources from the the source application

- Restore the source database over the new application
- Copy the four filesystem folders from the source application, cdnFiles, privateFiles, tempFiles, and wwwFiles