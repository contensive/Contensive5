
An application runs on one or more servers, called a Server-Group and a Server-Group can contain multiple applications. Configuration information is stored in a file config.json, typically in the d:\Contensive path.

## Developers

## References



